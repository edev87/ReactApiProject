export { default as Navigation } from "./Navigation";
export { default as Display } from "./Display";
export { default as Home } from "./Home";